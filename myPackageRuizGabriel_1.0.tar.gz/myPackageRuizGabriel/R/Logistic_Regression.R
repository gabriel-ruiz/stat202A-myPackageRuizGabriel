#########################################################
## Stat 202A - Homework 4
## Author: Gabriel Ruiz
## Date : 2 November 2017
## Description: This script implements logistic regression
## using iterated reweighted least squares using the code
## we have written for linear regression based on QR
## decomposition
#########################################################

#############################################################
## INSTRUCTIONS: Please fill in the missing lines of code
## only where specified. Do not change function names,
## function inputs or outputs. You can add examples at the
## end of the script (in the "Optional examples" section) to
## double-check your work, but MAKE SURE TO COMMENT OUT ALL
## OF YOUR EXAMPLES BEFORE SUBMITTING.
##
## Very important: Do not use the function "setwd" anywhere
## in your code. If you do, I will be unable to grade your
## work since R will attempt to change my working directory
## to one that does not exist.
#############################################################


################ Optional ################
## If you are using functions from Rcpp,
## uncomment and adjust the following two
## lines accordingly. Make sure that your
## cpp file is in the current working
## directory, so you do not have to specify
## any directories in sourceCpp(). For
## example, do not write
## sourceCpp('John_Doe/Homework/Stats202A/QR.cpp')
## since I will not be able to run this.

## library(Rcpp)
## sourceCpp(name_of_cpp_file)

##################################
## Function 1: QR decomposition ##
##################################

myQR <- function(A){

  ## Perform QR decomposition on the matrix A
  ## Input:
  ## A, an n x m matrix

  ########################
  ## FILL IN CODE BELOW ##
  ########################

  n<-nrow(A);m<-ncol(A)
  if(n<m){print("ERROR: if n=nrow(A) and m=ncol(A), we need to have n>=m!");return(NA)}
  R<-A
  Q<-diag(nrow=n)
  for(k in 1:(m-1)){
    x<-matrix(data = 0,nrow=n,ncol=1)
    x[k:n,1]<-R[k:n,k]#only copy subset of matrix we care about
    v<-x
    v[k]<-x[k]-sign(x[k,1])*norm(x,type="2")#precursor to u vector
    s<-norm(v,type="2")
    u<-v/s#normalize v
    R<- R-2*(u%*%(t(u)%*%R))
    # R<- 2*(u%*%(t(u)%*%R))-R
    Q<- Q-2*(u%*%(t(u)%*%Q))
    # Q<- 2*(u%*%(t(u)%*%Q))-Q
  }

  ## Function should output a list with Q.transpose and R
  ## Q is an orthogonal n x n matrix
  ## R is an upper triangular n x m matrix
  ## Q and R satisfy the equation: A = Q %*% R
  return(list("Q" = t(Q), "R" = R))

}

###############################################
## Function 2: Linear regression based on QR ##
###############################################

myLM <- function(X, Y){

  ## Perform the linear regression of Y on X
  ## Input:
  ## X is an n x p matrix of explanatory variables
  ## Y is an n dimensional vector of responses
  ## Use myQR (or myQRC) inside of this function

  ########################
  ## FILL IN CODE BELOW ##
  ########################
  n<-nrow(X);p<-ncol(X)
  # qr_info<-myQR(cbind(rep(1,n),X,Y))
  qr_info<-myQR(cbind(X,Y))
  #upper-triangular matrix
  # R1<-qr_info$R[1:(p+1),1:(p+1)]#rest of the matrix is unimportant; see dr. wu's stat 201 notes
  # Y1Star<-qr_info$R[1:(p+1),(p+2)]#rest of YStar is unimportant
  R1<-qr_info$R[1:(p),1:(p)]#rest of the matrix is unimportant; see dr. wu's stat 201 notes
  Y1Star<-qr_info$R[1:(p),(p+1)]#rest of YStar is unimportant
  beta_ls<-solve(R1)%*%Y1Star
  
  #
  Y2Star<-qr_info$R[(p+1):nrow(qr_info$R),(p+1)]
  RSS<-sum(Y2Star*Y2Star)#Residual sum of squares
  variance.hat<-RSS/(n-p-1)
  cov.beta.hat<-solve(t(X)%*%X)*variance.hat
  std.errors<-sqrt(diag(cov.beta.hat))
  ## Function returns the least squares solution vector
  return( list("beta_ls"=beta_ls,"std.errors"=std.errors) )
}

######################################
## Function 3: Logistic regression  ##
######################################

## Expit/sigmoid function
expit <- function(x){
  1 / (1 + exp(-x))
}

myLogistic <- function(X, Y){
  ## Perform the logistic regression of Y on X
  ## Input:
  ## X is an n x p matrix of explanatory variables
  ## Y is an n dimensional vector of binary responses
  ## Use myLM (or myLMC) inside of this function
  ########################
  ## FILL IN CODE BELOW ##
  ########################
  r<-nrow(X);c<-ncol(X)
  epsilon<-1e-6
  beta<-matrix(0,nrow=c)

  rep.col<-function(x,n){
    matrix(rep(x,each=n), ncol=n, byrow=TRUE)
  }
  w<-NULL
  while(TRUE){
    # print(dim(X));print(dim(beta))
    eta<-X%*%beta
    pr<-expit(eta)
    w<-pr*(1-pr)
    z<-eta+(Y-pr)/w
    sw<-sqrt(w)
    mw <- rep.col(sw,n=c)
    x_work<-mw*X#Note: element wise multiplication
    # print(dim(x_work))
    y_work<-sw*z
    beta_new<-myLMC(X=x_work,Y=y_work)
    # print(dim(beta_new))
    # print(dim(beta))
    err = sum(abs(t(beta_new) - matrix(beta,ncol=1) ) )
    beta = t(beta_new)
    if(err < epsilon){break()}
  }
  cov.beta.hat<-solve(t(X)%*%diag(c(w))%*%X)
  std.errors<-sqrt(diag(cov.beta.hat))
  return( list("beta"=beta,"std.errors"=std.errors) )
  ## Function returns the logistic regression solution vector
}


## Optional testing (comment out!)
# n <- 100
# p <- 4
# X    <- matrix(rnorm(n * p), nrow = n)
# beta <- rnorm(p)
# Y    <- 1 * (runif(n) < expit(X %*% beta))
# (logistic_beta <- myLogistic(cbind(rep(1,nrow(X)),X), Y))$std.errors
# # R_estimates<-glm(Y~0+X,family="binomial")$coefficients#the 0 specifies no additional intercept term
# R_estimates<-glm(Y~X,family="binomial")
# summary(R_estimates)$coefficients[,2]
# # norm(logistic_beta-R_estimates,type="2")
